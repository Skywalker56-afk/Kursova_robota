﻿using System;
using System.ComponentModel;
using System.Data;
using System.Net;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace ExchangeSoft
{
    class Model : INotifyPropertyChanged
    {
        public Model() => MakeRequest();
        private string _errorOccured;
        private double _baseAmount, _resultAmount;
        private object _jsonResults;
        private string _base, _convert;
        private const string _link = "http://data.fixer.io/api/latest?access_key="; 
        private const string _apiKey = "3e49ea2f1f6780ed1fa07d21977b9689"; // ключ доступа fixer.io
        public string ErrorOccured
        {
            get => _errorOccured;
            set
            {
                _errorOccured = value;
                OnPropertyChanged(nameof(ErrorOccured));
            }
        }
        public string Base // валюта из которой меняется
        {
            get => _base;
            set
            {
                _base = value.Split(':')[1].Replace(" ", "");
                GetResultAmount();
                OnPropertyChanged(nameof(Base));
            }
        }
        public string Converted // валюта в которую меняется
        {
            get => _convert;
            set
            {
                _convert = value.Split(':')[1].Replace(" ", "");
                GetResultAmount();
                OnPropertyChanged(nameof(Converted));
            }
        }
        public double BaseAmount // изначальное кол-во (валюты которую менять)
        {
            get => _baseAmount;
            set
            {
                _baseAmount = Convert.ToDouble(value);
                GetResultAmount();
                OnPropertyChanged(nameof(BaseAmount));
            }
        }
        public double ResultAmount // конечный результат (валюты в которую менять)
        {
            get => _resultAmount;
            set
            {
                _resultAmount = value;
                OnPropertyChanged(nameof(ResultAmount));
            }
        }
        public object JsonResults // JSON объект
        {
            get => _jsonResults;
            set
            {
                _jsonResults = value;
                OnPropertyChanged(nameof(JsonResults));
            }
        }
        public void MakeRequest()
        {
            try { // запрос для обновления(получения) данных
                var requestLink = $"{_link}{_apiKey}&format=1";
                using (WebClient wc = new WebClient())
                {
                    var json = wc.DownloadString(requestLink);
                    object result = JsonConvert.DeserializeObject(json);
                    JsonResults = result;
                }
            }
            catch(Exception) {
                ErrorOccured = "Произошла ошибка, перезапустите приложение! (либо отсутствует интернет)";
            }
        }
        public double GetCurrency(string currency) => Math.Round(Convert.ToDouble(JObject.Parse(JsonResults.ToString())["rates"][$"{currency}"]),1); // получаем значение из объекта
        public void GetResultAmount() {
            try { ResultAmount = BaseAmount * Math.Pow(GetCurrency(Base) / GetCurrency(Converted), -1); }
            catch(Exception) { }
        } 
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
}
