﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ExchangeSoft
{
    class ViewModel : INotifyPropertyChanged
    {
        private Model m { get; set; }
        public Model Model { get => m; set => m = value; }
        public ViewModel()
        {
            m = new Model() {
                Base = ": UAH",
                Converted = ":RUB",
                BaseAmount = 100
            };
            Console.WriteLine(m.ResultAmount);
        }
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
}
